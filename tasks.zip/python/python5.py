import module
from module import b1,name,age

print(module.b1())
print(name)
print(age)