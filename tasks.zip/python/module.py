def b1():
	return "привет"
def b2():
	return "пока"

name = "макс"
age = 54
number = 21

	